import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        String inputPath = "D:\\IBM\\IBM_Quest_data_generator\\C8T8S6I8DB20KN50R0.1.data";  // 输入文件路径
        String outputPath = "D:\\Dataset\\TA\\C8T8S6I8DB20KN50R0.1.txt";  // 输出文件路径
        convertSeqData(inputPath, outputPath);
    }

    public static void convertSeqData(String inputPath, String outputPath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {

            String line;
            int userId = 1; // 用户ID从1开始

            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                int itemsetCount = Integer.parseInt(parts[0]); // 项集数量
                int timestamp = 1; // 时间戳从1开始
                int index = 1; // 从第二个数字开始解析

                for (int i = 0; i < itemsetCount; i++) {
                    int itemsetLength = Integer.parseInt(parts[index]); // 当前项集长度
                    index++;

                    // 输出当前项集中的每个物品
                    for (int j = 0; j < itemsetLength; j++) {
                        String itemId = parts[index];
                        writer.write(userId + " " + timestamp + " " + itemId);
                        writer.newLine();
                        index++;
                    }

                    timestamp++; // 时间戳递增
                }

                userId++; // 处理完一行，用户ID递增
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}