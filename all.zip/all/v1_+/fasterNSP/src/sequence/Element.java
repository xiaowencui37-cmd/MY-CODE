package sequence;
 
import java.util.ArrayList;
import java.util.List;

/**
 * <title>Element Class</title>
 * Element of Sequence, basic operation of Element
 */

public class Element {
    private ArrayList<Integer> itemset;//琛ㄧず璇ュ厓绱犵殑椤圭洰锛屾寜鏁板瓧鐨勫崌搴忓瓨鏀�
     
    /**
     * 鏃犲弬鏁版瀯閫犳柟娉�
     * 鍒濆鍖栭」鐩泦 
     *
     */
    public Element() {
        this.itemset=new ArrayList<Integer>();
       }
    
   
    public Element(int [] items){
        this.itemset=new ArrayList<Integer>();
        for(int i=0;i<items.length;i++){
            this.addItem(items[i]);
        }
    }
    
    /**
     * 娣诲姞椤圭洰
     * 娣诲姞椤圭洰鍒伴」鐩泦涓�
     * @param item         琚坊鍔犵殑椤圭洰
     */
    public void addItem(int item){
        int i;
        for(i=0;i<itemset.size();i++){
            if(item == itemset.get(i))return;
            if(item > 0){
                if(item<itemset.get(i)){
                    break;
                }
            }
        }
        itemset.add(i,item);
    }
    
    /**
     * 鑾峰緱椤圭洰闆�
     * @return     椤圭洰闆�
     */
    public ArrayList<Integer> getItems(){
        return this.itemset;
    }
    /**
     * 鑾峰彇鏌愪綅缃厓绱�
     */
    public int getItem(int i){
		if(i<this.itemset.size()){
			return this.itemset.get(i);
		}else{
			System.err.println("绌哄厓绱犻敊璇紝Element.getLastItem()");
            return 0;
		}
    }
    
    /**
     * huoqudiyige
     */
    public int getFirstItem(){
    	return this.itemset.get(0);
    }
    /**
     * 鑾峰彇鏈�鍚庝竴涓綅缃殑椤圭洰
     * @return         椤圭洰
     */
    public int getLastItem(){
        if(this.itemset.size()>0){
            return itemset.get(itemset.size() - 1);
        }
        else{
            System.err.println("绌哄厓绱犻敊璇紝Element.getLastItem()");
            return 0;
        }
    }
 
    /**
     * 鏈柟娉曞垽鏂湰鍏冪礌鏄笉鏄寘鍚簬鍏冪礌e涓�
     * @param e           鍏冪礌
     * @return            true--鏄� false--鍚� 
     */
    public boolean isContainIn(Element e){
 //双指针匹配
        if(this.itemset.size()>e.itemset.size()){//濡傛灉涓や釜鍏冪礌澶у皬涓嶅悓锛屽垯涓轰笉鐩哥瓑
            return false;
        }
        int i=0,j=0;
        while(j<e.size() && i<this.itemset.size() ){
            if(this.itemset.get(i).intValue() == e.itemset.get(j).intValue()){
                i++;j++;
            }else{
                j++;
            }
        }
        if(i==this.itemset.size()){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * 鑾峰彇鍘婚櫎绗竴涓」鐩鐨勫厓绱�
     * @return          鍏冪礌
     */
    public Element getWithoutFistItem(){
        Element e=new Element();
        for(int i=1 ;i<this.itemset.size();i++){
            e.addItem(this.itemset.get(i).intValue());
        }
        return e;
    }
    
    /**
     * 鑾峰彇鍘婚櫎鏈�鍚庝竴涓」鐩鐨勫厓绱�
     * @return            鍏冪礌
     */
    public Element getWithoutLastItem(){
        Element e=new Element();
        for(int i=0 ;i<this.itemset.size()-1;i++){
            e.addItem(this.itemset.get(i).intValue());
        }
        return e;
    }
    
    /**
     * 鍒犻櫎椤圭洰
     * 椤圭洰浣嶇疆i涓婄殑椤圭洰
     * @param i        浣嶇疆搴忓彿
     * @return         
     */
    public int removeItem(int i){
        if(i<this.itemset.size()){
           return this.itemset.remove(i).intValue();
        }
        //System.err.println("鏃犳晥鐨勭储寮曪紒");
        return -1;
    }
    
    /**
     * 姣旇緝涓や釜鍏冪礌鐨勫ぇ灏�
     * 灏嗕紶閫掕繃鏉ョ殑鍙傛暟o涓庢湰瀵硅薄姣旇緝
     * @param o           琚瘮杈冪殑鍏冪礌
     * @return            int -- -1 鏈厓绱犲皬浜庡弬鏁�  1 鏈厓绱犲ぇ浜庡弬閫�
     */
     public int compareTo(Object o){
         Element e=(Element)o;
         int r=0;
         int i=0,j=0;
         while(i<this.itemset.size() && j<e.itemset.size()){
            if(this.itemset.get(i).intValue() < e.itemset.get(j).intValue()){
                r=-1;//鏈琫lement灏忎簬e
                break;
            }else{
                if(this.itemset.get(i).intValue() > e.itemset.get(j).intValue()){
                    r=1;//鏈琫lement澶т簬e
                    break;
                }
            }
            i++;j++;//椤圭洰鐩稿悓锛岄兘鎸囧悜涓嬩竴涓」鐩�
         }
         if(r==0){//濡傛灉鐩墠杩樻病鏈夋瘮杈冨嚭璋佸ぇ璋佸皬鐨勮瘽
             if(this.itemset.size()>e.itemset.size()){
                 r=1;
             }
             if(this.itemset.size()<e.itemset.size()){
                 r=-1;
             }
         }
         return r;
    }
     
    /**
     * 鑾峰彇椤圭洰闆嗙殑澶у皬
     * @return      int--澶у皬
     */
    public int size(){
        return this.itemset.size();
    }
    
    /**
     * 鍏冪礌鎷疯礉鏂规硶
     * 鎷疯礉椤圭洰闆�
     */
    public Element clone(){
        Element clone=new Element();
        for(int i:this.itemset){
            clone.addItem(i);
        }
        return clone;
    }
 
    /**
     * 涓嬪垽鏂袱涓厓绱犳槸鍚︾浉鍚�
     * @param o           
     * @return  true--鐩稿悓 false--涓嶅悓
     */
    public boolean equalsTo(Object o){
       boolean equal=true;
       Element e=(Element)o;
       if(this.itemset.size()!=e.itemset.size()){//濡傛灉涓や釜鍏冪礌澶у皬涓嶅悓锛屽垯涓轰笉鐩哥瓑
           equal=false;
       }
       for(int i=0;equal && i<this.itemset.size();i++){
           if(this.itemset.get(i).intValue()!=e.itemset.get(i).intValue()){
               equal=false;
           }
       }
       return equal;
   }
 
    /**
     * 閲嶅啓toString()
     * 鐢ㄤ簬杈撳嚭鏃剁殑瀛楃澶勭悊
     */
    public String toString(){
        StringBuffer s=new StringBuffer();
        if(this.itemset.size()>1){
            s.append("(");
        }
        for(int i=0;i<this.itemset.size();i++){
            s.append(this.itemset.get(i).intValue());
            if(i<this.itemset.size()-1){
                s.append(",");
            }
        }
        if(this.itemset.size()>1){
            s.append(")");
        }
        return s.toString();
    }
    public void setItemsNeg(){
    	for(int i =0; i<itemset.size(); i++){
    		int j = -itemset.get(i);
    		//System.out.println(j);
    		itemset.set(i, j);
    	}
    }

    /**
     * 生成所有合法的负项插空组合（不允许连续两个负项）
     * @return 包含所有合法负项组合的列表
     */
    public List<Element> generateNegativeCombinations() {
        List<Element> result = new ArrayList<>();

        int n = itemset.size();
        int[] items = new int[n];
        for (int i = 0; i < n; i++) {
            items[i] = itemset.get(i);
        }

        // 使用回溯法生成所有可能的符号组合
        backtrack(result, items, new int[n], 0, false);

        return result;
    }

    /**
     * 回溯法生成所有不连续负项的组合
     * @param result     存储结果
     * @param original   原始元素数组
     * @param current    当前构造的数组
     * @param index      当前处理到第几个元素
     * @param lastIsNeg  上一个是否为负项
     */
    private void backtrack(List<Element> result, int[] original, int[] current, int index, boolean lastIsNeg) {
        if (index == original.length) {
            Element e = new Element(current);


            // 检查是否全为负项 或 不存在连续负项
            boolean allNegative = true;
            boolean hasConsecutiveNeg = false;

            for (int i = 0; i < e.size(); i++) {
                if (e.getItem(i) > 0) {
                    allNegative = false;
                    break;
                }
            }

            if (!allNegative && containsConsecutiveNeg(e)) {
                return; // 存在正项且有连续负项，不加入结果
            }

            // 检查 e 中是否存在负项
            for (int item : e.getItems()) {
                if (item < 0) {
                    result.add(e); // 存在负项，才加入结果集
                    break;
                }
            }
            return;
        }

        // 当前项保持正号
        current[index] = original[index];
        backtrack(result, original, current, index + 1, false);

        current[index] = -original[index];
        backtrack(result, original, current, index + 1, true);

//        // 当前项取反（变成负项），但上一个不能也是负项
//        if (!lastIsNeg) {
//            current[index] = -original[index];
//            backtrack(result, original, current, index + 1, true);
//        }
    }

    private boolean containsConsecutiveNeg(Element e) {
        for (int i = 0; i < e.size() - 1; i++) {
            int curr = e.getItem(i);
            int next = e.getItem(i + 1);
            if (curr < 0 && next < 0) {
                return true;
            }
        }
        return false;
    }


    /**
     * verify whether this element is contain in element e
     */
    public boolean isContainInNeg(Element e){ 
    	
    	if(this.size() > e.size()){
    		//if length of this element is greater than the element e, they are different
            return false;
    	}
    	
    	for(int i =0; i<this.size(); i++){
    		int ivalue = this.getItem(i);
    		for(int j=0; j<e.size(); j++){
    			int jvalue = e.getItem(j);
    			if(-ivalue == jvalue){
    				return false;
    			}
    		}
    	}
    	return true; 
    }
 
    
}


